package org.example.methods;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.driver.BaseTest;
import org.example.page.LoginPage;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class Methods {
    WebDriver driver;
    public FluentWait<WebDriver> wait;
    JavascriptExecutor jsdriver;
    Logger logger =LogManager.getLogger(LoginPage.class);


    public Methods(){
        driver = BaseTest.driver;
        wait = new FluentWait<WebDriver>(driver);
        wait.withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofMillis(300))
                .ignoring(NoSuchElementException.class);
        jsdriver = (JavascriptExecutor) driver;
    }

    public void scrollWithJavaScript(By by){
        jsdriver.executeScript("arguments[0].scrollIntoView();",findElement(by));
    }

    public void addProductToFavorites() {

        logger.info("Sayfadaki ürünler listeye atılır.");
        List<WebElement> productList  = driver.findElements(By.className("product-cr"));
        waitBySeconds(3);
        logger.info("4 ürün favorilerime ekletilir.");
        for (int i = 6; i < productList.size(); i++) {

            WebElement element = productList.get(i)
                    .findElement(By.className("grid_2"))
                    .findElement(By.className("hover-menu"))
                    .findElement(By.className("add-to-favorites"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", element);
            if (i == 9) {
                break;
            }

        }

  /*  String text=methods.getText(By.id("//div[@role='alert']"));
    Assert.assertEquals("Ürün başarılı bir şekilde favorilerinize eklendi!",text);*/
    }

    public WebElement findElement(By by){
        return wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }

    public void click(By by){
        findElement(by).click();
    }

    public void clearInputArea(By by) {
        findElement(by).clear();
    }

    public void sendKeysEnter(By by) {
        findElement(by).sendKeys(Keys.ENTER);
    }

    public void waitBySeconds(long seconds){
        try{
            Thread.sleep(seconds*1000);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void productList(String attributeData) {
            List<WebElement> productList = driver.findElements(By.cssSelector(attributeData));
            Random r = new Random();
            productList.get(r.nextInt(productList.size())).click();
    }

    public void productListXpath(String attributeData) {
        waitBySeconds(3);
        List<WebElement> productListXpath = driver.findElements(By.xpath(attributeData));
        Random r = new Random();
        productListXpath.get(r.nextInt(productListXpath.size())).click();
        waitBySeconds(2);
    }

    public void sendKeys(By by, String text){
        findElement(by).sendKeys(text);
    }

    public void mouseHolder(By by){
        Actions actions = new Actions(driver);
        actions.moveToElement(findElement(by)).perform();
    }

    public void scrollWithAction(By by){
        Actions actions = new Actions(driver);
        actions.moveToElement(findElement(by)).build().perform();
    }

    public Select getSelect(By by){
        return new Select(findElement(by));
    }

    public void selectByText(By by, String text){
        getSelect(by).selectByVisibleText(text);
    }

    public boolean isElementVisible(By by){
        try{
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            return true;
        }catch (Exception e){
            return false;
        }
    }

    public String getText(By by){
        return findElement(by).getText();
    }

    public boolean iselementToBeClickable(By by) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(by));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Integer getInt(By by){
        return findElement(by).hashCode();
    }


}
