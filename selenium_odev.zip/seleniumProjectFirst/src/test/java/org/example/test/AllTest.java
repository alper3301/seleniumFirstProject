package org.example.test;

import org.example.driver.BaseTest;
import org.example.page.FavoritePage;
import org.example.page.HomePage;
import org.example.page.LoginPage;
import org.example.page.ProductPage;
import org.junit.Test;

public class AllTest extends BaseTest {

    @Test
    public void firstProjectTest(){
        LoginPage loginPage = new LoginPage();
        ProductPage productPage = new ProductPage();
        HomePage homePage = new HomePage();
        FavoritePage favoritePage = new FavoritePage();
        loginPage.loginTest();
        productPage.productTest();
        favoritePage.favoriteTest();
        favoritePage.favoriteTest2("2");
        favoritePage.favoriteTest3();
    }

    @Test
    public void stage(){

    }

}
