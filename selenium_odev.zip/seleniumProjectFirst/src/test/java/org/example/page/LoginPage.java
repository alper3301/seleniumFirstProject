package org.example.page;

import org.example.methods.Methods;
import org.openqa.selenium.By;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoginPage {

    Methods methods;
    Logger logger =LogManager.getLogger(LoginPage.class);

    public LoginPage(){
        methods = new Methods();
    }

    //ana sayfa üzerinden giriş sayfasına gidilir
    //input alanları doldurulur ve giriş tuşuna basılır
    //giriş sayfasında olup olmadığı kontrol edilir
    public void loginTest() {
        methods.click(By.xpath("//div[@class='menu-top-button login']"));
        methods.waitBySeconds(3);
        methods.sendKeys(By.id("login-email"), "nese.aydin@testinium.com");
        methods.sendKeys(By.id("login-password"), "1q2w3e4r5t");
        methods.waitBySeconds(2);
        methods.click(By.xpath("//button[@class='ky-btn ky-btn-orange w-100 ky-login-btn']"));
        methods.waitBySeconds(5);
        String loginCheck = methods.getText(By.cssSelector(".common-sprite"));
        System.out.println("Login Başarılı : " + loginCheck);
        logger.info("Login Başarılı : " + loginCheck);
        methods.waitBySeconds(3);
    }
}
