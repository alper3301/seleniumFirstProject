package org.example.page;

import org.example.methods.Methods;

import java.lang.reflect.Method;

public class HomePage {

    Methods methods;

    public HomePage(){
        methods = new Methods();
    }

    public void homeTest(){

    }
}
