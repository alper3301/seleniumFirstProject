package org.example.page;

import org.example.methods.Methods;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FavoritePage {

    public WebElement i;
    Methods methods;
    Logger logger =LogManager.getLogger(LoginPage.class);

    public FavoritePage(){
        methods = new Methods();
    }

    public void favoriteTest(){
        methods.waitBySeconds(2);
        methods.isElementVisible(By.xpath("//a[contains(text(),'favorilerinize')]"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@href='https://www.kitapyurdu.com/']"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@href='puan-katalogu']"));
        methods.waitBySeconds(2);
        //methods.click(By.xpath("//a[@href='index.php?route=product/best_sellers&list_id=730&filter_points_catalog=true&sort=purchased&order=DESC']"));
        methods.click(By.xpath(("//img[@title='Puan Kataloğundaki Türk Klasikleri']")));
        methods.waitBySeconds(3);
        //methods.scrollWithAction(By.cssSelector("#review-reply-button"));
        //methods.waitBySeconds(5);
        //methods.scrollWithAction(By.xpath("//select[@onchange='location = this.value;']//option[@value='https://www.kitapyurdu.com/index.php?route=product/best_sellers&sort=rating&order=DESC&list_id=730&filter_points_catalog=true&filter_points_catalog=true']"));
        //methods.waitBySeconds(5);
        methods.selectByText(By.xpath("//div[@class='sort']//select"),"Yüksek Oylama");
        methods.waitBySeconds(2);
        methods.mouseHolder(By.xpath("//span[contains(text(),'Tüm Kitaplar')]"));
        methods.waitBySeconds(3);
        methods.click(By.xpath("//a[contains(text(),'Hobi')]"));
        methods.waitBySeconds(2);
        methods.productListXpath("//div[@class='cover']");
        methods.waitBySeconds(2);
        methods.click(By.id("button-cart"));
        methods.waitBySeconds(1);
        methods.mouseHolder(By.xpath("//a[contains(text(),'Listelerim')]"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//a[contains(text(),'Favorilerim')]"));
        methods.waitBySeconds(2);
        methods.mouseHolder(By.xpath("//div[@class='product-cr'][3]"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//div[@class='product-cr'][3]//a[@data-title='Favorilerimden Sil']"));
        methods.waitBySeconds(1);
        methods.click(By.id("cart-items"));
        methods.waitBySeconds(1);
        methods.click(By.id("js-cart"));
        methods.waitBySeconds(2);
    }

    public void favoriteTest2(String quantity){
        methods.clearInputArea(By.name("quantity"));
        methods.sendKeys(By.name("quantity"), quantity);
        methods.sendKeysEnter(By.name("quantity"));
    }

    public void favoriteTest3() {
        methods.waitBySeconds(1);
        methods.click(By.xpath("//i[@class='fa fa-refresh green-icon']"));
        methods.waitBySeconds(3);
        methods.click(By.xpath("//div[@class='buttons']//a[@class='button red']"));
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[contains(text(),'Yeni bir adres kullanmak istiyorum.')]"));
        methods.waitBySeconds(2);
        methods.sendKeys(By.id("address-firstname-companyname"), "Gizli");
        methods.sendKeys(By.id("address-lastname-title"), "Gizli1");
        methods.selectByText(By.id("address-zone-id"), "Mersin");
        methods.waitBySeconds(2);
        methods.selectByText(By.id("address-county-id"), "MEZİTLİ");
        methods.waitBySeconds(2);
        methods.sendKeys(By.id("district"),"ATATÜRK MAH");
        methods.waitBySeconds(2);
        methods.click(By.xpath("//div[contains(text(),'ATATÜRK MAH')]"));
        methods.waitBySeconds(2);
        methods.sendKeys(By.xpath("//textarea[@id='address-address-text']"), "Kehribar Mah. Tesbih Sok.");
        methods.waitBySeconds(2);
        methods.sendKeys(By.id("address-telephone"), "1111118888");
        methods.waitBySeconds(2);
        methods.sendKeys(By.id("address-mobile-telephone"), "5445559090");
        methods.waitBySeconds(2);
        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(2);
        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(2);
        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(2);
        boolean a = methods.isElementVisible(By.xpath("//span[@class='error']"));
        if(a==true){
            System.out.println("Hatalı giriş yapıldı ya da boş bırakıldı");
        }else {
            System.out.println("Kart bilgileri doğru girildi");
        }
        methods.waitBySeconds(2);
        methods.click(By.xpath("//a[@class='checkout-logo']"));
        methods.waitBySeconds(2);
        methods.mouseHolder(By.xpath("//a[@href='https://www.kitapyurdu.com/index.php?route=account/account']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//*[@id=\"header-top\"]/div/div[1]/div[1]/ul/li/div/ul/li[4]/a"));
        methods.waitBySeconds(2);
    }




}
