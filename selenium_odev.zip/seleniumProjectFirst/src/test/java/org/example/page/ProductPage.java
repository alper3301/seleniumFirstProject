package org.example.page;

import org.example.methods.Methods;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ProductPage {

    Methods methods;

    public ProductPage(){
        methods = new Methods();
    }

    public void productTest(){
        methods.waitBySeconds(3);
        methods.sendKeys(By.id("search-input"), "Oyuncak");
        methods.waitBySeconds(3);
        methods.click(By.cssSelector(".common-sprite.button-search"));
        methods.waitBySeconds(3);
        methods.scrollWithAction(By.xpath("//div[@class='product-cr'][7]"));
        methods.waitBySeconds(3);
        methods.addProductToFavorites();
    }


}
